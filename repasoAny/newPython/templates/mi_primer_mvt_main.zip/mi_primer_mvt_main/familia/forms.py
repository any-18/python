from django import forms
from datetime import date

class PersonaForm(forms.Form):
    nombre = forms.CharField(label="Nombre", max_length=100)
    apellido = forms.CharField(label="Apellido", max_length=100)
    email = forms.EmailField(label="Email")
    years = [x for x in range(date.today().year, 1900, -1)]
    fechaNacimiento = forms.DateField(label="Fecha de nacimiento", widget=forms.SelectDateWidget(years=years))
